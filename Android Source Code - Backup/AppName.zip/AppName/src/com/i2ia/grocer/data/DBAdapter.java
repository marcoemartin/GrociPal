package com.i2ia.grocer.data;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;

import com.i2ia.grocer.Constants;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Manager for saving lists using a local SQLite database
 * @author Daniel
 *
 */
public class DBAdapter{
	static final String KEY_ROWID = "_id";
	static final String KEY_NAME= "name";
	static final String KEY_PRODNUM = "productnum";
	static final String KEY_CATEGORY = "category";
	static final String KEY_IMG = "imageName";
	static final String TAG = "DBAdapter";
	static final int numOfColumns = 5;
	
	//static final String DATABASE_TABLE = "lists";
	static final int DATABASE_VERSION = 1;
	
	static final String DATABASE_GET_TABLES = "SELECT name FROM sqlite_master WHERE type='table';";
	static String DATABASE_PATH = null;
	
	final Context context;
	
	DatabaseHelper DBHelper;
	SQLiteDatabase db;
	/**
	 * 
	 * @param context
	 */
	public DBAdapter(Context context){
		this.context = context;
		DBHelper = new DatabaseHelper(context);
		DATABASE_PATH = "/data/data/" + "com.i2ia.grocer" + "/databases/" + Constants.DATABASE_NAME;
	}
	
	/**
	 * 
	 * @author Daniel
	 *
	 */
	private static class DatabaseHelper extends SQLiteOpenHelper{
		DatabaseHelper(Context context){
			super(context,Constants.DATABASE_NAME, null, DATABASE_VERSION);
		}
		
		public void onCreate(SQLiteDatabase db)
		{
		}
		/**
		 * 
		 */
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
			
			Log.w(TAG, "Upgrading database from version" + oldVersion + "");
//					+ "to" + newVersion + ", which will destroy all old data");
//			db.execSQL("DROP TABLE IF EXISTS list");
			//onCreate(db);
		}
		@Override
		public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion){
			Log.w(TAG, "Upgrading database from version" + oldVersion + "");
			//onCreate(db);
		}
	}
	/**
	 * 
	 * @return
	 */
	public DBAdapter open() {
		
		
		String  mydir = "data/data/com.i2ia.grocer/databases";
		File file = new File(mydir);
		
		if(!file.exists()){
			file.mkdir();
			
				try {
					Log.d("COPYTAG","COPYING");
					copyDB(context.getAssets().open(Constants.DATABASE_NAME),new FileOutputStream(DATABASE_PATH));
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
		
		db = DBHelper.getWritableDatabase();
		return this;
	}
	
	public void copyDB(InputStream inputStream,OutputStream outputStream){
		
		byte[] buffer = new byte[1024];
		int length;
		try {
			while((length = inputStream.read(buffer))>0){
				outputStream.write(buffer,0,length);
			}
			inputStream.close();
			outputStream.close();
			outputStream.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	/**
	 * 
	 */
	public void close(){
		DBHelper.close();
	}
	/**
	 * 
	 * @param tableName
	 * @param prodName
	 * @param productNum
	 * @return
	 */
	public long insertItem(String tableName, String name, String productnumber, String category, String img){
		ContentValues initValues = new ContentValues();
		initValues.put(KEY_NAME, name);
		initValues.put(KEY_PRODNUM, productnumber);
		initValues.put(KEY_CATEGORY, category);
		initValues.put(KEY_IMG, img);
		return db.insert(tableName, null, initValues);
	}
	
	/**
	 * 
	 * @param rowId
	 * @return
	 */
	public boolean deleteItem(long rowId, String tableName){
		return (db.delete(tableName, KEY_ROWID + "=" + rowId,null) > 0);
	}
	/**
	 * 
	 * @param name
	 * @return
	 */
	public boolean addTable(String name){
		if(!getTables().contains(name)){
		db.execSQL("create table if not exists " + name +" (_id integer primary key autoincrement," +
				"name text not null, productnum integer not null, category text not null, imageName text not null);");
		return true;
		}else{
			return false;
		}
	}
	/**
	 * 
	 * @return
	 */
	public ArrayList<String> getTables(){
		ArrayList<String> userTables = new ArrayList<String>();
		String[] censored_tables= new String[6];
		
		censored_tables[0] = "android_metadata";
		censored_tables[1] = "sqlite_sequence";
		censored_tables[2] = "hygenicitems2014";
		censored_tables[3] = "fooditems2014";
		censored_tables[4] = "housecareitems2014";
		censored_tables[5] = "foodStores2014";
		
		Cursor c = db.rawQuery(DATABASE_GET_TABLES, null);
		if (c.moveToFirst()) {
		    do {
		    	String tableName = c.getString(0);
		    	if(!Arrays.asList(censored_tables).contains(tableName)){
		    		userTables.add(tableName);
		    		
		    	}
		    	c.moveToNext();
		    }while(!c.isAfterLast());
		}
		
		return userTables;
	}
	/**
	 * 
	 * @param table
	 * @return
	 */
	public ArrayList<String> getAllItemNames(String table){
		ArrayList<String> allItems= new ArrayList<String>();
		Cursor c = db.query(table, new String[] {KEY_NAME}, null,null,null,null,null);
		if (c.moveToFirst()) {
		    do {
		    	allItems.add(c.getString(0));
		        c.moveToNext();
		    }while(!c.isAfterLast());
		}
		return allItems;
	}
	
	/**
	 * Returns list of all product numbers in table
	 * @param table
	 * @return
	 */
	public ArrayList<Integer> getAllProductNum(String table){
		ArrayList<Integer> allItems= new ArrayList<Integer>();
		Cursor c = db.query(table, new String[] {KEY_PRODNUM}, null,null,null,null,null);
		if (c.moveToFirst()) {
		    do {
		    	allItems.add(c.getInt(0));
		        c.moveToNext();
		    }while(!c.isAfterLast());
		}
		return allItems;
	}
	
	
	/**
	 * 
	 * @param table
	 * @return
	 */
	public ArrayList<String> getAllItemImages(String table){
		ArrayList<String> allImgs= new ArrayList<String>();
		Cursor c = db.query(table, new String[] {KEY_IMG}, null,null,null,null,null);
		if (c.moveToFirst()) {
		    do {
		    	allImgs.add(c.getString(0));
		        c.moveToNext();
		    }while(!c.isAfterLast());
		}
		return allImgs;
	}
	
	/**
	 * 
	 * @param rowId
	 * @return an array with the value of every column as an element of the list. 
	 * e.g. _id, name, product number, category
	 */
	public String[] getItem(long rowId,String tableName){

		String[] row= new String[numOfColumns];
		Cursor c = db.rawQuery("Select * FROM " +tableName +" WHERE _id = " + rowId,null);
//		Cursor c = 
//				db.query(tableName, new String[] {KEY_ROWID,KEY_NAME,KEY_PRODNUM,KEY_CATEGORY}, KEY_ROWID + "=" + rowId,null,
//						null,null,null,null);
		if (c.moveToFirst()) {
			int indx = 0;
			while(indx < row.length){
				row[indx] = (c.getString(indx));
				indx++;
			}
		}
		return row;
	}
	/**
	 * 
	 * @param rowId
	 * @param name
	 * @param productnum
	 * @return
	 */
	public boolean updateItem(long rowId,String tableName, String name, String productnum, String category, String img){
		ContentValues args = new ContentValues();
		args.put(KEY_NAME, name);
		args.put(KEY_PRODNUM, productnum);
		args.put(KEY_CATEGORY, category);
		args.put(KEY_IMG, img);
		return (db.update(tableName, args, KEY_ROWID + "=" + rowId, null) > 0);
	}
	/**
	 * Deletes given table from database
	 * Return true if successful
	 * @param table
	 * @return 
	 */
	public void deleteTable(String table){
		db.execSQL("DROP TABLE IF EXISTS '" + table + "'");
		}
	/**
	 * 
	 * @param storesTable
	 * @return
	 */
	public ArrayList<String> getAllStoreNames(String storesTable) {
		ArrayList<String> storeNames= new ArrayList<String>();
		Cursor c = db.query(storesTable, new String[] {"storeName"}, null,null,null,null,null);
		if (c.moveToFirst()) {
		    do {
		    	storeNames.add(c.getString(0));
		        c.moveToNext();
		    }while(!c.isAfterLast());
		}
		return storeNames;
	}
	/**
	 * 
	 * @param storesTable
	 * @return
	 */
	public ArrayList<String> getAllStoreImages(String storesTable) {
		ArrayList<String> storeImages= new ArrayList<String>();
		Cursor c = db.query(storesTable, new String[] {"iconName"}, null,null,null,null,null);
		if (c.moveToFirst()) {
		    do {
		    	storeImages.add(c.getString(0));
		        c.moveToNext();
		    }while(!c.isAfterLast());
		}
		return storeImages;
	}
	

}
