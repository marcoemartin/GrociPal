package com.i2ia.grocer.activities.secondary;

import java.util.ArrayList;

import com.i2ia.grocer.Constants;
import com.i2ia.grocer.R;
import com.i2ia.grocer.activities.primary.ManageListsActivity;
import com.i2ia.grocer.data.DBAdapter;
import com.i2ia.grocer.data.RemoteDatabaseConnector;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
/**
 * Activity for viewing a list in detail
 * @author Daniel
 *
 */
public class ListViewActivity extends SecondaryBaseActivity {
	private static String tableName;
	private static ArrayList<String> tableContents = new ArrayList<String>();
	private static ListView listView;
	private static ListViewClickListener listViewClickListener;
	private static DBAdapter db;
	private static ArrayAdapter<String> mArrayAdapter;
	private static Context context;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		ListViewActivity.context = this;
		//setContentView(R.layout.activity_list_view);
		
		db = new DBAdapter(this);
		
		//Displaying Home Button on ActionBar
		ActionBar actBar = getSupportActionBar();
		actBar.setDisplayHomeAsUpEnabled(true);
		actBar.setHomeButtonEnabled(true);
//        
        //Get list Name
        Intent intent = getIntent();
		Bundle nameBundle = intent.getExtras();
		tableName = nameBundle.getString(Constants.TABLE_TAG);
		actBar.setTitle(tableName);//Display list/table name
		
		//Get table contents
		getTableContents();
		
		//Display table contents
        mArrayAdapter = new ArrayAdapter<String>(this,R.layout.list_view_item,tableContents);
		listView = (ListView) findViewById(R.id.listView_items);	
		listView.setAdapter(mArrayAdapter);			
		listView.setOnItemClickListener(listViewClickListener);
       
		//Enable Buttons
		clickableButtons();
	}
	
	/**
	 * Return contents (list items) of current table
	 */
	public void getTableContents(){
		db.open();		
		//Clear tableContents so listView doesn't double onResume()
		tableContents.clear();
		tableContents = db.getAllItemNames(tableName);
		db.close();
	}

	
	/**
	 * Manages selection of menu items
	 */
	public boolean onOptionsItemSelected(MenuItem item){
	    switch (item.getItemId()) {
	    //If menu item selected is trash icon
        case R.id.action_delete:{
        	confirmDelete();
        	}
            return true;
        default:
            return super.onOptionsItemSelected(item);
    }
}
	
	/**
	 * Handles onClick behavior of items
	 * @author Daniel
	 *
	 */
	private class ListViewClickListener implements ListView.OnItemClickListener{

		@Override
		public void onItemClick(AdapterView<?> parent, View view,
				int position, long id) {
			// Handle item clicks here - Link to itemInfo page.
			
		}
			
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.list_view, menu);
		return true;
	}

	/**
	 * Dialog box to confirm delete of list
	 */
	public void confirmDelete(){
		DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
		    @Override
		    public void onClick(DialogInterface dialog, int which) {
		        switch (which){
		        case DialogInterface.BUTTON_POSITIVE:
		        	db.open();
	        		db.deleteTable(tableName);
	        		Intent intent = new Intent(getApplicationContext(),ManageListsActivity.class);
	        		startActivity(intent);
		            break;

		        case DialogInterface.BUTTON_NEGATIVE:
		            break;
		        }
		    }
		};

		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage("Delete " + tableName  +"?").setPositiveButton("Yes", dialogClickListener)
		    .setNegativeButton("No", dialogClickListener).show();
		
	}
	/**
	 * Displays result from pricecheck
	 * @param cost
	 */
	public static void displayPrice(String cost){
		DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				switch(which){
				case DialogInterface.BUTTON_POSITIVE:
					break;
				}
			}
		};
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setMessage("Cost: $" + cost).setPositiveButton("Okay", dialogClickListener).show();
	}
	
	/**
	 * Manages onClick behavior of buttons
	 */
	public void clickableButtons(){
		Button addItemsButton = (Button) findViewById(R.id.button_add_items);
		addItemsButton.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				//pass table name to ItemBrowserActivity
				//Insert Items into table as user adds items
				Intent intent = new Intent(getApplicationContext(),ItemBrowserActivity.class);
				intent.putExtra(Constants.TABLE_TAG, tableName);
				startActivity(intent);
			}
		});
		
		
		Button priceCheckbutton = (Button) findViewById(R.id.button_check_price);
		priceCheckbutton.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				db.open();
				ArrayList<Integer> productNumbers = db.getAllProductNum(tableName);
				RemoteDatabaseConnector mRemoteDB = new RemoteDatabaseConnector();
				long price = mRemoteDB.getPrice(productNumbers, ListViewActivity.this);
				
			}
		});
		
		
		Button shopByStoreButton = (Button) findViewById(R.id.button_by_store);
		shopByStoreButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				//Start ItemBrowserActivity with specific store selected
				Intent intent  = new Intent(getApplicationContext(),ItemBrowserActivity.class);
				//intent.putExtra(Constants.SELECTED_STORE, "STORE ID");
				startActivity(intent);
			}
		});
	}

	@Override
	protected int getLayoutResourceId() {
		return R.layout.activity_list_view;
	}

	@Override
	protected int getMenuResourceId() {
		return R.menu.list_view;
	}
	
	public static void priceCalculated(String cost){
		displayPrice(cost);
	}
	
	
	

}
