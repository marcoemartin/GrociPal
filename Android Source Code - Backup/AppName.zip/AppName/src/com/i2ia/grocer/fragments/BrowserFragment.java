package com.i2ia.grocer.fragments;

import java.util.ArrayList;

import com.i2ia.grocer.Constants;
import com.i2ia.grocer.R;
import com.i2ia.grocer.activities.secondary.CustomListAdapter;
import com.i2ia.grocer.activities.secondary.ListViewActivity;
import com.i2ia.grocer.data.DBAdapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
/**
 * Manages fragments used in ItemBrowserActivity tabs
 * @author Daniel
 *
 */
public class BrowserFragment extends Fragment {
	public DBAdapter db;
	private static ArrayList<String> addedProductNames = new ArrayList<String>();
	private static ArrayList<String> addedImageResources = new ArrayList<String>();
	private static ArrayAdapter<String> mArrayAdapter = null;
	private static ListView listView;
	private Context context;
	private String tableName;
	private String dataTableName;
	private View rootView;

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
		context = getActivity();
        db = new DBAdapter(context);
        rootView = inflater.inflate(R.layout.fragment_itembrowser, container, false);
        
        //Add content to view
        loadListView(rootView); 
        onClickButtons(rootView);
        return rootView;
    }
	public void setDataTable(String i_tableName, String userTable){
		dataTableName = i_tableName;
		tableName = userTable;

	}
	
	/**
	 * Manage click of 'Done' Button of item adding process
	 */
	public void onClickButtons(View rootView){
		
		//Done button, once user has finished adding items
		Button doneButton = (Button) rootView.findViewById(R.id.button_done);
		doneButton.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent  = new Intent(context, ListViewActivity.class);
				intent.putExtra(Constants.TABLE_TAG, tableName);
				startActivity(intent);
				
			}
		});
	}
	
	/**
	 * 
	 * @param rootView
	 */
	public void loadListView(View rootView){
		//Get Name of user made tables
		db.open();
		addedProductNames = db.getAllItemNames(dataTableName);
		addedImageResources = db.getAllItemImages(dataTableName);
		db.close();
		
		//Filling list view with lists 
		//mArrayAdapter = new ArrayAdapter<String>(context,R.layout.list_view_item, addedProductNames);
		listView = (ListView) rootView.findViewById(R.id.listView_items);
		CustomListAdapter cla = new CustomListAdapter(context, addedProductNames, addedImageResources, R.layout.list_view_items_browser);
		listView.setAdapter(cla);
		listView.setOnItemClickListener(new ListItemClickListener());
	}

	/**
	 * Manages Clicks of Recent Lists display
	 * @author Daniel
	 *
	 */
	private class ListItemClickListener implements ListView.OnItemClickListener{
		public void onItemClick(AdapterView<?> parent, View view, int position, long id){
			selectItem(position);
		}
		private void selectItem(int position){
			db.open();
			String[] row = db.getItem(position + 1,dataTableName);
			db.insertItem(tableName, row[1], row[2], row[3], row[4]);
			db.close();
		}
	}
	
	
}
