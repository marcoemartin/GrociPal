package com.i2ia.grocer;
/**
 * Class for storing and accessing constants
 * @author Daniel
 *
 */
public class Constants {
	//Used for refering to which drawer is open in navigation drawer
	public static final String HOME_ACTIVITY = "HomeActivity";
	public static final String STORE_ACTIVITY = "StoreActivity";
	public static final String MANAGE_ACTIVITY = "ManageActivity";
	public static final String FAVOURITES_ACTIVITY = "FavouritesActivity";
	public static final String SETTINGS_ACTIVITY = "SettingsActivity";

	//Used for sending and recieving list/table names for intent.putExtra() & Bundle.getString()
	public static final String TABLE_TAG = "TABLE_TAG";
	//Used for sending and receiving search strings between classes
	public static final String SEARCH_TAG = "SEARCH_TAG";
	//Used for identifying which class started a certian activity
	public static final String CALLER_TAG = "CALLER_TAG";
	//Used for sharedPreference key-value pair
	public static final String NOTIF_KEY = "NOTIF_KEY";
	//Used for sharedPreference key-alue pair
	public static final String TRAVEL_KEY = "TRAVEL_KEY";
	//Used for passing selected store to ItemBrowserActivity class
	public static final String SELECTED_STORE = "SELECTED_STORE";
	//Refers to foodItems table in PredefinedItems.db
	public static final String FOOD_TABLE = "fooditems2014";
	//Refers to foodItems table in PredefinedItems.db
	public static final String HOUSECARE_TABLE = "housecareitems2014";
	//Refers to foodItems table in PredefinedItems.db
	public static final String HYGIENE_TABLE = "hygenicitems2014";
	//Refers to internaldatabase
	public static String DATABASE_NAME = "internaldatabase.db";
	
	

}
