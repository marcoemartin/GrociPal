package com.i2ia.grocer.activities.secondary;

import com.i2ia.grocer.Constants;
import com.i2ia.grocer.fragments.BrowserFragment;
import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.util.Log;
/**
 * 
 * @author Daniel
 *
 */
public class ItemBrowserHelper extends FragmentPagerAdapter {
	private String tableName;
	private BrowserFragment foodFragment, houseFragment, hygieneFragment;

	
	public ItemBrowserHelper(FragmentManager fm, String i_tableName) {
		super(fm);
		tableName = i_tableName;
		
		foodFragment = new BrowserFragment();
    	foodFragment.setDataTable(Constants.FOOD_TABLE, tableName);
    	
    	houseFragment = new BrowserFragment();
    	houseFragment.setDataTable(Constants.HOUSECARE_TABLE,tableName);
    	
    	hygieneFragment = new BrowserFragment();
    	hygieneFragment.setDataTable(Constants.HYGIENE_TABLE,tableName);
		
	}
	@Override
	public Fragment getItem(int index) {
		switch (index) {
        case 0:
        	Log.d("CASE","0");
            // Return food fragment
            return foodFragment;
            
        case 1:
        	Log.d("CASE","1");
            // Return housecare fragment
            return houseFragment;
            
        case 2:
        	Log.d("CASE","2");
            // Return hygiene fragment
            return hygieneFragment;
            
         default:
        	 return null;
		}
    }

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 3;
	}

}
