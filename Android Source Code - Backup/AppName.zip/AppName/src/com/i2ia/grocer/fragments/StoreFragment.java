package com.i2ia.grocer.fragments;

import com.i2ia.grocer.R;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

public class StoreFragment extends Fragment {

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
 
        View rootView = inflater.inflate(R.layout.fragment_favourites_stores, container, false);
         
        return rootView;
    }
	
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
		inflater.inflate(R.menu.favourites, menu);
		
	}
	
	/**
	 * Manages selection of menu items
	 */
	public boolean onOptionsItemSelected(MenuItem item){
	    switch (item.getItemId()) {
	    //If menu item selected is trash icon
        case R.drawable.ic_input_add:{
        	Log.d("ACTIONICON","PLUS CLICKED");
        	//Add stores to favourites
        	//
        	}
            return true;
        default:
            return super.onOptionsItemSelected(item);
	    }

	}
	
}
