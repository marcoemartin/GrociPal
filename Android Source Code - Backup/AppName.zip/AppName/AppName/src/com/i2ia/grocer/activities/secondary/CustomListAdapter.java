package com.i2ia.grocer.activities.secondary;

import java.util.ArrayList;
import java.util.List;

import com.i2ia.grocer.Constants;
import com.i2ia.grocer.activities.primary.ManageListsActivity;
import com.i2ia.grocer.data.DBAdapter;
import com.i2ia.grocer.R;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class CustomListAdapter extends BaseAdapter{
	private ArrayList<String> items;
	private ArrayList<String> images;
	private int layoutResourceId;
	private Context context;
	LayoutInflater myInflater;


	public CustomListAdapter(Context c, ArrayList<String> item, ArrayList<String> image) {
		items = item;
		images = image;
		context = c;
		myInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		//layoutResourceId = resourceId;
	}
	

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return items.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return items.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if(convertView==null){
			convertView = myInflater.inflate(R.layout.list_view_items_browser, parent, false);
			TextView item = (TextView) convertView.findViewById(R.id.txt);
			ImageView img = (ImageView) convertView.findViewById(R.id.img);
			item.setText(items.get(position));
			int resID = context.getResources()
									.getIdentifier(images.get(position), 
											"drawable", 
											context.getPackageName());
			img.setImageResource(resID);
		}

		return convertView;
	}

	/**
	 * Dialog box that shows a description of product and description(if exists)
	 */
	public void infoDialogBox(){
		AlertDialog OptionDialog = new AlertDialog.Builder(context).create();
		
		Dialog d = new Dialog(context);
		d.setContentView(R.layout.custom_dialog_box);
		d.setTitle(R.string.description);
		d.show();
	}
	
	public void dialogButtons(View v){
		switch(v.getId()){
			case R.id.ok_button:
				//OK Clicked
			case R.id.fav_button:
				//fav clicked
			default:
				break;
		}
	}
	
	
}

