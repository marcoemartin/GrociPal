package com.i2ia.grocer.activities.secondary;

import com.i2ia.grocer.Constants;
import com.i2ia.grocer.R;
import com.i2ia.grocer.activities.primary.BaseActivity;
import com.i2ia.grocer.data.UserSettingsManager;

import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBar.Tab;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.SearchView;
import android.view.Menu;
import android.view.View;
import android.widget.ToggleButton;
/**
 * Activity for managing user settings
 * @author Daniel
 *
 */
public class SettingsActivity extends BaseActivity {
	private ToggleButton notif_toggle,travel_toggle;
	private UserSettingsManager settingsManager;
	private SearchView searchView = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

        
		//Get Toggle buttons
		notif_toggle = (ToggleButton) findViewById(R.id.toggleButton_notif);
		travel_toggle = (ToggleButton) findViewById(R.id.toggleButton_travel);
		
		//Get current state of toggle buttons
		settingsManager = new UserSettingsManager(this);
		boolean notif_on = settingsManager.getPreference(Constants.NOTIF_KEY);
		boolean travel_on = settingsManager.getPreference(Constants.TRAVEL_KEY);	
		
		//Apply saved state of toggle buttons
		notif_toggle.setChecked(notif_on);
		travel_toggle.setChecked(travel_on);
		
		//Add click listeners
		toggleButtons();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.settings, menu);
		return true;
	}
	
	/**
	 * Manages onClick behavior of toggle buttons
	 */
	public void toggleButtons(){
		notif_toggle.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				if(((ToggleButton) v).isChecked()){
					//Turn notification freature ON
					settingsManager.SetPreference(Constants.NOTIF_KEY, true);
					
					}
				else{
					settingsManager.SetPreference(Constants.NOTIF_KEY, false);
				}
			}
			
		});
		
		travel_toggle.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				if(((ToggleButton) v).isChecked()){
					settingsManager.SetPreference(Constants.TRAVEL_KEY, true);
					
					}
				else{
					settingsManager.SetPreference(Constants.TRAVEL_KEY, false);
				}	
			}
		});
		
	}

	@Override
	protected int getLayoutResourceId() {
		return R.layout.activity_settings;
	}

	@Override
	protected int getMenuResourceId() {
		return R.menu.settings;
	}

	@Override
	protected String getActivityString() {
		// TODO Auto-generated method stub
		return Constants.SETTINGS_ACTIVITY;
	}



}
