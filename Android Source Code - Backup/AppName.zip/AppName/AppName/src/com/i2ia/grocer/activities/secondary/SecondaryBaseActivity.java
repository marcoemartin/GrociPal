package com.i2ia.grocer.activities.secondary;

import com.i2ia.grocer.R;

import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarActivity;
/**
 * Base Activity extended by all activites that need navigation drawer
 *
 * @author Daniel
 * @version 1.0 
 */
public abstract class SecondaryBaseActivity extends ActionBarActivity {
	
	/**
	 * Abstract method gets layout to expand
	 * @return integer referring to layout resource
	 */
	protected abstract int getLayoutResourceId();
	
	/**
	 * Abstract method gets menu to expand
	 * @return integer referring to menu resource
	 */
	protected abstract int getMenuResourceId();

	
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(getLayoutResourceId());
		
		ActionBar actBar = getSupportActionBar();
		actBar.setDisplayHomeAsUpEnabled(true);
        actBar.setHomeButtonEnabled(true);
		actBar.setIcon(R.drawable.inv_icon);
		actBar.setBackgroundDrawable(new ColorDrawable(0xFF01D16B));
		
		
	}

}

	


