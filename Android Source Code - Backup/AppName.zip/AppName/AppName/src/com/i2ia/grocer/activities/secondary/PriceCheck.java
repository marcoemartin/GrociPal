package com.i2ia.grocer.activities.secondary;

import com.i2ia.grocer.R;
import com.i2ia.grocer.R.layout;
import com.i2ia.grocer.R.menu;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.os.Build;
/**
 * Activity to display cost of a list at different stores
 * @author Daniel
 *
 */
public class PriceCheck extends SecondaryBaseActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.activity_price_check);
	}
		
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.price_check, menu);
		return true;
	}

	@Override
	protected int getLayoutResourceId() {
		return R.layout.activity_price_check;
	}

	@Override
	protected int getMenuResourceId() {
		return R.menu.price_check;
	}


}
