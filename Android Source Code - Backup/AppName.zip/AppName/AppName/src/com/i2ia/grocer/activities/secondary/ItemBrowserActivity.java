package com.i2ia.grocer.activities.secondary;


import com.i2ia.grocer.Constants;
import com.i2ia.grocer.R;

import android.os.Bundle;
import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBar.Tab;
import android.view.Menu;
/**
 * Activity for browsing items to add to a list
 * @author Daniel
 *
 */
public class ItemBrowserActivity extends SecondaryBaseActivity implements ActionBar.TabListener {

	
	
	private String[] tabs = {"Food", "HouseCare", "Hygiene"};
	private ViewPager viewPage;
	private ItemBrowserHelper adapter;
	private ActionBar actBar;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.activity_item_browser);
		//Get Database Adapter

		Intent intent = getIntent();
		Bundle intent_bundle = intent.getExtras();
		String tableName = intent_bundle.getString(Constants.TABLE_TAG);

		actBar = getSupportActionBar();
        viewPage = (ViewPager) findViewById(R.id.pager_item_browser);
        adapter = new ItemBrowserHelper(getSupportFragmentManager(),tableName);
        viewPage.setAdapter(adapter);
        actBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
        
        
        
        for(String tab: tabs){
        	actBar.addTab(actBar.newTab().setText(tab).setTabListener(this));
        }
        
    	viewPage.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
    		 
    	    @Override
    	    public void onPageSelected(int position) {
    	        actBar.setSelectedNavigationItem(position);
    	    }
    	 
    	    @Override
    	    public void onPageScrolled(int arg0, float arg1, int arg2) {
    	    }
    	 
    	    @Override
    	    public void onPageScrollStateChanged(int arg0) {
    	    }
    	});	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.item_browser, menu);
		return true;
	}
	@Override
	protected int getLayoutResourceId() {
		return R.layout.activity_item_browser;
	}
	@Override
	protected int getMenuResourceId() {
		// TODO Auto-generated method stub
		return R.menu.list_view;
	}
	@Override
	public void onTabReselected(Tab tab, FragmentTransaction arg1) {
		// TODO Auto-generated method stub
		viewPage.setCurrentItem(tab.getPosition());
		
	}
	@Override
	public void onTabSelected(Tab tab, FragmentTransaction arg1) {
		// TODO Auto-generated method stub
		viewPage.setCurrentItem(tab.getPosition());
		
	}
	@Override
	public void onTabUnselected(Tab arg0, FragmentTransaction arg1) {
		// TODO Auto-generated method stub
		
	}

}
