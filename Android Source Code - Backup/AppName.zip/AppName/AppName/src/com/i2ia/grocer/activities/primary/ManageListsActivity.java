package com.i2ia.grocer.activities.primary;

import java.util.ArrayList;

import com.i2ia.grocer.Constants;
import com.i2ia.grocer.R;
import com.i2ia.grocer.data.DBAdapter;
import com.i2ia.grocer.activities.secondary.ListViewActivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.SearchView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
/**
 * Activity for managing lists (edit,new,delete)
 * @author Daniel
 *
 */
public class ManageListsActivity extends BaseActivity {
	private ArrayList<String> user_lists = new ArrayList();
	private ListView listDisplay;
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		//Populates Listview with users lists
		DBAdapter db =  new DBAdapter(getApplicationContext());
		db.open();
		ArrayList<String> user_lists = db.getTables();
		
		//Remove default tables in database

		//Display Lists
		listDisplay = (ListView) findViewById(R.id.display_lists);	
		listDisplay.setAdapter(new ArrayAdapter<String>(this,R.layout.manage_lists_item,user_lists));
		listDisplay.setOnItemClickListener(new ListItemClickListener());		
	}
	
	private class ListItemClickListener implements ListView.OnItemClickListener{
		public void onItemClick(AdapterView<?> parent, View view, int position, long id){
			selectItem(position);
		}
		private void selectItem(int position){
			//List item clicked, launches ListViewActivity
			String selectedList = user_lists.get(position);
			Intent intent = new Intent(getApplicationContext(),ListViewActivity.class);
			intent.putExtra(Constants.TABLE_TAG, selectedList);
			startActivity(intent);
		}
	}
	
	@Override
	protected int getLayoutResourceId() {
		// TODO Auto-generated method stub
		return R.layout.activity_list_management;
	}

	@Override
	protected int getMenuResourceId() {
		// TODO Auto-generated method stub
		return R.menu.list_management;
	}

	@Override
	protected String getActivityString() {
		// TODO Auto-generated method stub
		return Constants.MANAGE_ACTIVITY;
	}



}
