package com.i2ia.grocer.data;
/**
 * Manages connections to servers database of items
 * @author Daniel
 *
 */
public class ServerDatabaseConnector {
	
	
	

}
