package com.i2ia.grocer.activities.primary;

import java.util.ArrayList;

import com.i2ia.grocer.Constants;
import com.i2ia.grocer.R;
import com.i2ia.grocer.activities.secondary.ListViewActivity;
import com.i2ia.grocer.activities.secondary.NewEditList;
import com.i2ia.grocer.activities.secondary.SearchResultsActivity;
import com.i2ia.grocer.data.DBAdapter;
import com.i2ia.grocer.data.RemoteDatabaseConnector;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.support.v7.widget.SearchView;
/**
 * Activity for home page of app
 * @author Daniel
 *
 */
public class HomeActivity extends BaseActivity {
	
    private static ListView listView;
    private static ArrayList<String> userLists = new ArrayList<String>();
	private static ArrayAdapter<String> mArrayAdapter = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//Manage onClick behavior of buttons
		onClickButtons();

	}	
	public void loadListView(){
		userLists.clear();
		//Get Name of user made tables
		DBAdapter db = new DBAdapter(this);
		db.open();
		//All tables in database
		userLists = db.getTables();
		Log.d("USER_lists", userLists.toString());
		db.close();
		
		//Filling list view with lists 
		mArrayAdapter = new ArrayAdapter<String>(this,R.layout.manage_lists_item,userLists);
		listView = (ListView) findViewById(R.id.listView_items_home);
		listView.setAdapter(mArrayAdapter);
		listView.setOnItemClickListener(new ListItemClickListener());	
	}
	/**
	 * Manages Clicks of Recent Lists display
	 * @author Daniel
	 *
	 */
	private class ListItemClickListener implements ListView.OnItemClickListener{
		public void onItemClick(AdapterView<?> parent, View view, int position, long id){
			selectItem(position);
		}
		private void selectItem(int position){
			String selectedList = userLists.get(position);
			//Pass name of selected table to ListViewActivity class
			Intent intent = new Intent(getApplicationContext(),ListViewActivity.class);
			intent.putExtra(Constants.TABLE_TAG, selectedList);
			startActivity(intent);
		}
	}
	
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		
		//Creates and handles searchView
		MenuItem menuSearchItem = menu.findItem(R.id.action_search);
		SearchView searchView = (SearchView) MenuItemCompat.getActionView(menuSearchItem);
		searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
			
			@Override
			public boolean onQueryTextSubmit(String query) {
				Intent intent = new Intent(getApplicationContext(),SearchResultsActivity.class);
				intent.putExtra(Constants.SEARCH_TAG, query);
				startActivity(intent);
				return false;
			}
			
			@Override
			public boolean onQueryTextChange(String query) {
				return false;
			}
		});
		
		return true;
	}
	
	@Override
	/**
	 * Override, loadlists each time HomeActivity is resumed or started
	 */
	public void onResume(){
		loadListView();
		super.onResume();
	}



	@Override
	protected int getMenuResourceId(){
		// TODO Auto-generated method stub
		return R.menu.home;
	}
	
	@Override
	protected int getLayoutResourceId() {
		// TODO Auto-generated method stub
		return R.layout.activity_home;
	}

	@Override
	protected String getActivityString() {
		// TODO Auto-generated method stub
		return Constants.HOME_ACTIVITY;
	}
	
	/**
	 * Handles clicks of buttons
	 */
	private void onClickButtons(){
		Button newListButton = (Button) findViewById(R.id.button_new_list);
		newListButton.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				Intent intent = new Intent(getApplicationContext(),NewEditList.class);
				startActivity(intent);
			}
		});
		
		Button manageListsButton = (Button) findViewById(R.id.button_manage_lists);
		manageListsButton.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				Intent intent = new Intent(getApplicationContext(),ManageListsActivity.class);
				startActivity(intent);
			}
		});
		
		Button favouritesButton = (Button) findViewById(R.id.button_favourites);
		favouritesButton.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				Intent intent = new Intent(getApplicationContext(),FavouritesActivity.class);
				startActivity(intent);
			}
		});
		
		
	}
	
	
	
	
	
	
}	
	


