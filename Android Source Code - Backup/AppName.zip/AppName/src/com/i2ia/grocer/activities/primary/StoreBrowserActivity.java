package com.i2ia.grocer.activities.primary;

import java.util.ArrayList;

import com.i2ia.grocer.Constants;
import com.i2ia.grocer.R;
import com.i2ia.grocer.activities.secondary.ListViewActivity;
import com.i2ia.grocer.activities.secondary.StoreInfoActivity;
import com.i2ia.grocer.data.DBAdapter;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
/**
 * Activity for browsing stores
 * @author Daniel
 *
 */
public class StoreBrowserActivity extends BaseActivity {
	private DBAdapter db;
	private static ArrayList<String> storeNames = new ArrayList<String>();
	private static ArrayList<String> storeIDs = new ArrayList<String>();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		db = new DBAdapter(this);
		onClickButtons();//Add onClick behavior to buttons
		loadListView();
	}
	
	public void onClickButtons(){

	}
	
	public void loadListView(){
		//Get Name of user made tables
//		new AsyncTask<View, Void, Void>(){
//			private View v;
//			@Override
//			protected Void doInBackground(View... params) {
//				v = params[0];
//				db.open();
//				storeNames = db.getAllStoreNames(Constants.STORES_TABLE);	
//				ArrayList<String> storeImageNames = db.getAllStoreImages(Constants.STORES_TABLE);
//				Log.d("StoreIMGNAMES", storeImageNames.toString());
//				db.close();
//				
//				Log.d("STORENAMES",storeNames.toString());
//				Log.d("StoreIMG",storeIDs.toString());
//				ListView listView = (ListView) v.findViewById(R.id.display_stores);
//				CustomBrowserListAdapter cla = new CustomBrowserListAdapter(v.getContext(), storeNames, storeImageNames,R.layout.list_view_store_browser);
//				listView.setAdapter(cla);
//				listView.setOnItemClickListener(new ListItemClickListener());
//				return null;
//			}
//			protected void onPostExecutre(){
//				Log.d("ONPostExecute","Thread finished");
//			}
//
//		}.execute(findViewById(R.id.store_browser_layout));
		
		db.open();
		storeNames = db.getAllStoreNames(Constants.STORES_TABLE);	
		ArrayList<String> storeImageNames = db.getAllStoreImages(Constants.STORES_TABLE);
		Log.d("StoreIMGNAMES", storeImageNames.toString());
		db.close();
		
		Log.d("STORENAMES",storeNames.toString());
		Log.d("StoreIMG",storeIDs.toString());
		
		//Filling list view with lists 
		ListView listView = (ListView) this.findViewById(R.id.display_stores);
		CustomBrowserListAdapter cla = new CustomBrowserListAdapter(this, storeNames, storeImageNames,R.layout.list_view_store_browser);
		listView.setAdapter(cla);
		listView.setOnItemClickListener(new ListItemClickListener());
	}
	
	
	

	@Override
	protected int getLayoutResourceId() {
		return R.layout.activity_store_browser;
	}

	@Override
	protected int getMenuResourceId() {
		// TODO Auto-generated method stub
		return R.menu.store_browser;
	}

	@Override
	protected String getActivityString() {
		// TODO Auto-generated method stub
		return Constants.STORE_ACTIVITY;
	}
	
	
	
	/**
	 * Handles clicks of store items
	 * @author Daniel
	 *
	 */
	private class ListItemClickListener implements ListView.OnItemClickListener{
		public void onItemClick(AdapterView<?> parent, View view, int position, long id){
			selectItem(position);
		}
		private void selectItem(int position){
			String selectedStore = storeNames.get(position);
			Intent intent = new Intent(getApplicationContext(),StoreInfoActivity.class);
			intent.putExtra(Constants.STORE_NAME,selectedStore);
			startActivity(intent);
			
		}
	}
	
	/**
	 * 
	 * @author Daniel
	 *
	 */
	public class CustomBrowserListAdapter extends BaseAdapter{
		private ArrayList<String> items;
		private ArrayList<String> images;
		private Context context;
		LayoutInflater myInflater;
		private int rowLayout;
		
		public CustomBrowserListAdapter(Context c, ArrayList<String> item, ArrayList<String> image,int i_rowLayout) {
			items = item;
			context = c;
			myInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			rowLayout = i_rowLayout;
			images = getIDs(image);
			//layoutResourceId = resourceId;
			
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return items.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return items.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}
		
		
		public ArrayList<String> getIDs(ArrayList<String> storeIconNames){
			ArrayList<String> storeIDs = new ArrayList<String>();
			for(String s: storeIconNames){
				storeIDs.add(Integer.toString(
						context.getResources()
						.getIdentifier(s, "drawable", 
								context.getPackageName())));
			}
			return storeIDs;
			
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			if(convertView==null){
				convertView = myInflater.inflate(rowLayout, parent, false);
				TextView item = (TextView) convertView.findViewById(R.id.txt);
				ImageView img = (ImageView) convertView.findViewById(R.id.img);
				
				item.setText(items.get(position));
				Log.d("IMAGESTAG",images.get(position));
				img.setImageResource(Integer.parseInt(images.get(position)));	
				
			}else{
				
				LinearLayout view = (LinearLayout) convertView;
				TextView name = (TextView) view.getChildAt(1);
				ImageView img = (ImageView) view.getChildAt(0);
				
				name.setText(items.get(position));
				img.setImageResource(Integer.parseInt(images.get(position)));
			}
			return convertView;
		}

		
		
	}
	
	



}
