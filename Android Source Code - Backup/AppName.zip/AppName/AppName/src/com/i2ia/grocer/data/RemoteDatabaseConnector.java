package com.i2ia.grocer.data;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.i2ia.grocer.activities.secondary.ListViewActivity;

/**
 * Manages connections to servers database of items
 * @author Daniel
 *
 */
public class RemoteDatabaseConnector {
	String priceQuery = "SELECT price FROM ExampleStore WHERE productnum";
	
//	/**
//	 * Tester method to connect and retrieve data from remoteDatabase
//	 */
//	public void getAllItems(){
//		
//		
//		//AccessItems accItem = new AccessItems();
//		//accItem.execute();
//		
//	}
	
	/**
	 * Gets price given list of product numbers
	 * @param productNumbers
	 * @return
	 */
	public long getPrice(ArrayList<Integer> productNumbers, ListViewActivity activity){
		
		//Build query string
		for(int i = 0;i < productNumbers.size();i++){
			if((i == (productNumbers.size() - 1))){
				//Last item to add
				priceQuery = priceQuery + " = " + productNumbers.get(i);
			}else{
				priceQuery = priceQuery + " = " + productNumbers.get(i) + " or productnum";
			}
		}
		
		PriceChecker priceCheck = new PriceChecker(priceQuery, activity);
		priceCheck.execute();
		
		return 0;
	}
	
	/**
	 * Given list of items retrieves price information from remoteDB
	 */
	class PriceChecker extends AsyncTask<String, String, String>{
		private String queryString;
		private ListViewActivity activity;
		
		public PriceChecker(String i_queryString,ListViewActivity listViewAct){
			queryString = i_queryString;
			this.activity = listViewAct;
		}

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			String url = "http://138.51.194.231/webservice/getPrice.php";
			InputStream isr = null;
			String result = null;
			
			ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
			nameValuePairs.add(new BasicNameValuePair("Query",queryString));
			
			
			try{
				HttpClient httpClient = new DefaultHttpClient();
				HttpPost httpPost = new HttpPost(url);
				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
				
				HttpResponse response = httpClient.execute(httpPost);
				
				HttpEntity entity = response.getEntity();
				isr = entity.getContent();
				Log.d("ISR",isr.toString());
				Log.d("PASS1","connection success ");
			}catch(Exception e){
			 Log.d("ErrorDB","Could not connect to database");	
			 
			}
			
			//Convert InputStream string of cost
			try{
				BufferedReader reader = new BufferedReader(new InputStreamReader(isr,"iso-8859-1"),8);
				StringBuilder sb = new StringBuilder();
				String line = null;
				
				while((line = reader.readLine()) != null){
					sb.append(line + "\n");
					}
				isr.close();
				result = sb.toString();
				
				Log.d("SB",sb.toString());
				Log.d("pass2", "Connection Successful");
			}catch(Exception e){
				Log.d("Fail2",e.toString());
			}
			
			
			
			return result;
		}
		protected void onPostExecute(String cost){
			activity.priceCalculated(cost);
		}
	}
//	/**
//	 * Querys remote db and gets back JSON OBJECT
//	 * @author Daniel
//	 *
//	 */
//	class AccessItems extends AsyncTask<String,String, JSONObject>{
//		private String name;
//		private JSONObject result;
//		protected void onPreExecute(){
//			
//		}
//		
//		@Override
//		protected JSONObject doInBackground(String... params) {	
//			//Location of server, will change
//			String url = "http://192.168.43.26/webservice/getItems.php";
//			JSONObject result = null;
//			InputStream isr = null;
//			String productNumber = "1";
//			
//			//List of name value pairs that will be passed as POST variables to .php code
//			ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
//			nameValuePairs.add(new BasicNameValuePair("ProductNumber",productNumber));
//			
//			//Send namevalue pairs to server
//			//get response as InputStream
//			try{
//				HttpClient httpClient = new DefaultHttpClient();
//				HttpPost httpPost = new HttpPost(url);
//				httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
//				HttpResponse response = httpClient.execute(httpPost);
//				HttpEntity entity = response.getEntity();
//				isr = entity.getContent();
//				Log.d("ISR",isr.toString());
//				Log.d("PASS1","connection success ");
//			}catch(Exception e){
//			 Log.d("ErrorDB","Could not connect to database");	
//			 
//			}
//			
//			//Convert InputStream to JSONObject
//			try{
//				BufferedReader reader = new BufferedReader(new InputStreamReader(isr,"iso-8859-1"),8);
//				StringBuilder sb = new StringBuilder();
//				String line = null;
//				while((line = reader.readLine()) != null){
//					sb.append(line + "\n");
//					}
//				isr.close();
//
//				String jsonObj = sb.toString();
//				jsonObj = jsonObj.substring(jsonObj.indexOf("{"),jsonObj.indexOf("]"));
//				result = new JSONObject(jsonObj);
//				
//				Log.d("JSON",result.toString());
//				Log.d("pass2", "Connection Successful");
//				name = result.getString("Name");
//			}catch(Exception e){
//				Log.d("Fail2",e.toString());
//			}
//			
//			try{
//				
////				JSONObject json_data = new JSONObject(result.toString());
////				String name = (json_data.getString("Name"));
//				
//				Log.d("NAMETAG",name);
//			}catch(Exception e){
//				Log.d("Fail3", e.toString());
//			}
//			//Return JSONObject result
//			return result;
//
//				
//			
//			
//		}
//		
//		protected void onPostExecute(String name){
//			
//		}
		
		
		
		
	//}
	
	
	

}
